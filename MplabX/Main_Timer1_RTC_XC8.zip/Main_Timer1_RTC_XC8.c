/*
 * File:   Main_Timer1_RTC_XC8.c
 * Author: el_pa
 *
 * Created on 4 de agosto de 2020, 04:01 PM
 */


#include <xc.h>
#include <stdio.h>
#include "..\1_libetriasYO\config.h"
#include "..\1_libetriasYO\lcd_yo.h"
//#include "..\1_libetriasYO\Timer0.h"
//#include "..\1_libetriasYO\serial.h"
#include "..\1_libetriasYO\Timer1.h"

//para usar RTC poner un cristal en los pines RC0 y RC1
#define tmr1_load   32767

int seg=50,min=59,hr=1;

void init(void){
    CMCON = 0X07;           //desactivo comparadores
    ADCON1bits.PCFG = 0x0F;    // 0x0F Todos los puertos  todo digital
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 0b00011111;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
    
    PORTE = 0X00;
    LATE = 0X00;
    TRISE = 0X00;
    //LATEbits.LATE0 =0;
    lcd_init();               //se inicializa la pantalla LCD.
}

void main(void) {
    float cm;
    char datos[20];
    init();
    //timer0_config(T0_16_BIT, T0_INTERNAL, T0_DIV_128);
    timer1_config(T1_EXTERNAL_SYNC,T1_DIV_BY_1,T1_CLK_OUT);
    lcd_clear();          //Limpiar pantalla LCD
    lcd_putc("**IDE MPLAB X**");  //se muestra una cadena de caracteres en la pantalla LCD
    lcd_putc("\n******XC8****LCD4x20");  
    lcd_putc("\nuControladores"); 
    lcd_putc("\nTimer1 RTC PIC18F4550");
    //lcd_cursor_on(1);
    //lcd_clear();
    delay_ms(500);    
    globalinterrupts = 1;
    peripheralInterrupt = 1;
    TMR1Interrupt = 1;

    TMR1 = tmr1_load;
    while(1){
        lcd_putc("\f**RTC**");
        lcd_gotoxy(1,2);
        sprintf(datos,"%i:%i:%i",hr,min,seg);
        lcd_putc(datos);
        led1 = !led1;
        delay_ms(100);
        
        //while parpadea cada 100ms
        //tmr0 frec 10
        //tmr1 frec 5
    }
    return;
}

//void interrupt ISR_TIMER_0(void){
void __interrupt() ISR_TIMER1(void){
    /*if (TMR0IF == 1){
    //if(INTCONbits.TMR0IF == 1){         //interrupcion timer0 Flag
        set_T0(18660);
        led5 = !led5;
        
        INTCONbits.TMR0IF = 0;
    }else*/
    
    if(PIR1bits.TMR1IF == 1){
            //if (TMR1IF == 1){
        TMR1 = tmr1_load;
        seg++;
        if (seg>59){
            seg=0;
            min++;
            if (min>59){
                min=0;
                hr++;
                if (hr>23){
                    hr=0;
                }
            }
        }
        led3 = !led3;
        //TMR1IF = 0;
        PIR1bits.TMR1IF = 0;
    }
    /*else if(INTCONbits.INT0IF == 1){   //interrupcion RB0 Flag
        
        INTCONbits.INT0IF = 0;
    }else if(PIR1bits.RCIF == 1){   //interrupcion serial Flag
        
        //char dataRX = RCREG;
        //UART_write(dataRX);
        printf(" Interupcion en RX USART \n\r");
        PIR1bits.RCIF = 0;
    }*/
    
}