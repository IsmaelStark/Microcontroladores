#include <xc.h>
#include "config.h"


void f1();
void init(void){
    /*INICIO
	CLRF PORTA ;  Initialize PORTA by
	CLRF LATA ; Alternate method
	MOVLW 0Fh ; Configure A/D 
	MOVWF ADCON1 ; for digital inputs
	MOVLW 07h ; Configure comparators
	MOVWF CMCON ; for digital input
	MOVLW b'11001111'; 0CFh ;b'11001111'  ;d'207' ; Value used to 
	MOVWF  TRISA ;  Set RA<3:0> as inputs;  RA<5:4> as outputs
    
	CLRF PORTB
	CLRF LATB
	MOVLW 0h
	MOVWF  TRISB

	CLRF PORTD
	CLRF LATD
	MOVLW 0FFh
	MOVWF  TRISD*/
    
    PORTA = 0X00;
    LATA = 0X00;
    ADCON1=0X0F;
    CMCON = 0X07;
    //TRISA = 0b11001111;
    TRISAbits.RA0 = 1;
    TRISAbits.RA1 = 1;
    TRISAbits.RA2 = 1;
    TRISAbits.RA3 = 1;
    TRISAbits.RA4 = 0;
    TRISAbits.RA5 = 0;
    TRISAbits.RA6 = 1;
    //TRISAbits.RA7 = 1;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
    
    PORTD = 0X00;
    LATD = 0X00;
    TRISD = 0XFF;
    
    
    
}

void main(void) {
    int x = 1;
    init();
    LATB=1;
    delay_ms(100);
    while(1){
        f1();
        
        /*LATBbits.LATB0 = 1;
        delay_ms(100);
        LATBbits.LB0 = 0;
        //LATB0_bit = 0;
        delay_ms(100);*/
    }
    return;
}

void f1(){
   //int x = 1;
    
   for(int i=2;i<=8;i++){
       LATB <<=1;
       delay_ms(500);
   }
    for(int i=2;i<=8;i++){
       LATB >>=1;
       delay_ms(500);
   }
}