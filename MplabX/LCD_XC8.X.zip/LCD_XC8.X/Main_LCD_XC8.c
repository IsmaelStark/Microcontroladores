/*
 * File:   Main_LCD_XC8.c
 * Author: el_pa
 *
 * Created on 30 de junio de 2020, 11:23 AM
 */

#include <xc.h>
#include "config.h"
//#include "lcd.h"
#include "lcd1.h"
#include <stdio.h> 

float decimal= 4.47;
int entero=20;
char buffer_lcd[20];

void init(void){
    PORTA = 0X00;
    LATA = 0X00;
    ADCON1=0X0F;
    CMCON = 0X07;
    //TRISA = 0b11001111;
    TRISAbits.RA0 = 1;
    TRISAbits.RA1 = 1;
    TRISAbits.RA2 = 1;
    TRISAbits.RA3 = 1;
    TRISAbits.RA4 = 0;
    TRISAbits.RA5 = 0;
    TRISAbits.RA6 = 1;
    //TRISAbits.RA7 = 1;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
}

void main(void) {
    init();
    lcd_init();               //se inicializa la pantalla LCD.
    while(1)
    {
        lcd_clear();          //Limpiar pantalla LCD
        lcd_gotoxy(1,1);      //Ubicar el cursor en fila 1, columna 1
        lcd_putc("**IDE MPLAB X**");  //se muestra una cadena de caracteres en la pantalla LCD
        lcd_gotoxy(2,1);      //Ubicamos el cursor en fila2, columna 1
        lcd_putc("******XC8******");
        __delay_ms(1000);     
        lcd_clear();         
        lcd_gotoxy(1,1);     
        lcd_putc("uControladores"); 
        lcd_gotoxy(2,1);     
        lcd_putc("   PIC 18F4550");
        __delay_ms(500); 
        
        
        for(unsigned char i=0;i<15;i++)
        {
            __delay_ms(100); 
            lcd_shift_left();
        }

        for(unsigned char i=0;i<30;i++) 
        {
            __delay_ms(100);  
            lcd_shift_right();
        }
        
        lcd_clear();
        lcd_gotoxy(1,1);
        lcd_putc("*Van a........**"); 
        //lcd_putc("*LCD - UCntrol**");
        __delay_ms(500); 
        lcd_gotoxy(2,1);      
        lcd_write_char('R');   
        __delay_ms(100);      
        lcd_write_char('E'); 
        __delay_ms(100);      
        lcd_write_char('P'); 
        __delay_ms(100);     
        lcd_write_char('R');  
        __delay_ms(100);    
        lcd_write_char('O'); 
        __delay_ms(100); 
        lcd_write_char('B'); 
        __delay_ms(100); 
        lcd_write_char('A'); 
        __delay_ms(100); 
        lcd_write_char('R'); 
        __delay_ms(100);
        lcd_write_char(' '); 
        __delay_ms(100);
        lcd_write_char('x'); 
        __delay_ms(100);
        lcd_write_char('D'); 
        
        lcd_clear(); 
        lcd_gotoxy(1,1); 
        sprintf(buffer_lcd,"Float: %03.2f", decimal);
        lcd_putc(buffer_lcd); 
        
        lcd_gotoxy(2,1);
        sprintf(buffer_lcd,"Int: %d",entero); 
        lcd_putc(buffer_lcd);
        
        
        __delay_ms(2000);  
    }
}

