/*
 * File:   Main_analog.c
 * Author: el_pa
 *
 * Created on 2 de julio de 2020
 */
#include <xc.h>
#include "config.h"

//Pag 261 secc 21
/*1. Configure the A/D module: pag 265
? Configure analog pins, voltage reference and
digital I/O (ADCON1)
? Select A/D input channel (ADCON0)
? Select A/D acquisition time (ADCON2)
? Select A/D conversion clock (ADCON2)
? Turn on A/D module (ADCON0)
2. Configure A/D interrupt (if desired):
? Clear ADIF bit 
? Set ADIE bit 
? Set GIE bit 
3. Wait the required acquisition time (if required).
4. Start conversion:
? Set GO/DONE bit (ADCON0 register)*/


//primero Tenemos ADC de
// 10 bit -> 2^10= 1024, 12  bit 2^12, 8 bits 2^8
//El voltaje de referencia:
// 5v -> adc = 5/ 1023 = 4.8mV 
//si fuera para 3.3v -> adc = 3.3V/1023 = 3.22mV 

//20Mhz pero con pll a 48Mhz-> 1/48MHz = 20.8ns : Tosc

//////Select A/D acquisition time (ADCON2)  minimo = 2.45?s(pag264))
//The A/D conversion requires 11 TAD per 10-bit conversion.(p267)
// 1TAD > 0.7us(pag 400)

// 8Tosc -> 8*20.8ns =  166.4ns 
// 16Tosc -> 16*20.8ns = 332.8ns 
// 64Tosc -> 64*20.8ns = 1.33?s  : 1TAD            Este nos sirve
// 2.45?s < xTAD
////
//TACQ = 2*TAD = 2*1.33?s = 2.66us > 2.45us //cualquiera de estos2
//TACQ = 4*TAD = 4*1.33?s = 5.32us > 2.45us 
//


void init(void){
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 1; //RA0 ENTRADA
    ADCON1bits.PCFG = 0;    // Todos los puertos Analogicos(pag260)
    ADCON1bits.VCFG = 0;    //voltaje referencia VDD_VSS
    ADCON0 = 0;             //canal 0, go/done=0(idle), ADON = ad disabled
    
    //Select A/D acquisition time (ADCON2)  minimo = 2.45?s(pag264))
    ADCON2bits.ACQT = 1;    //2*TAD
    //ADCON2bits.ACQT = 2; //4*TAD
    ADCON2bits.ADCS = 6; //FOSC/64
    ADCON2bits.ADFM = 1; //Right justified 
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
    PORTD = 0X00;
    LATD = 0X00;
    TRISD = 0X00;
}

void main(void) {
    unsigned adcv=0;
    init();
    ADCON0bits.ADON = 1;//habilitamos ADC
    while(1){
        ADCON0bits.ADON = 1;//habilitamos ADC
        ADCON0bits.GO_DONE = 1;//comenzamos conversion
        while(ADCON0bits.GO_DONE == 1);//mientras este haciendo la conversion
        
        LATB = ADRESL; 
        LATD = ADRESH; 
        
        adcv = ADRES; //aqui manda los 10bit enteros leidos por el ADC
        
        ADCON0bits.ADON = 0;//deshabilitamos ADC
        delay_ms(100);
    }
    return;
}
