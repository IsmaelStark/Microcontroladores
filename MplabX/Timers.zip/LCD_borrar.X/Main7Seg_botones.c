/*
 * File:   newmain.c
 * Author: el_pa
 *
 * Created on 2 de julio de 2020, 12:17 PM
 */


#include <xc.h>
#include "..\1_libetriasYO\config.h"
#include "..\1_libetriasYO\lcd1.h"
#include <stdio.h>
#include "..\1_libetriasYO\ADClib.h"

#include "..\1_libetriasYO\SerialClase.h"

#define d1 LATAbits.LA1
#define d2 LATAbits.LA0

#define suma PORTCbits.RC0
#define resta PORTCbits.RC1

#define max 4

//Orden de display GFEDCBA
//N�meros del 0-9 en hexadecimal
char num[11]= {0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X67,0b01000000};
int cont, uni, dec,seleccion=0;


void main(void) {
    cont = 0;
    //Definir puertos
    ADCON1bits.PCFG= NO_ANALOGS;   //no analogicos
    CMCON = 0X07;           //desactivo comparadores
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 0X00;
    //Salida (display)
    PORTD = 0X00;
    LATD = 0X00;
    TRISD = 0X00;
    //Salida (bit)
    PORTC = 0X00;
    LATC= 0X00;
    TRISC = 0X0F;
    
    while(true){
        //separaci�n de n�meros
        if (resta ==0 & suma ==1){ //// o puede ser escrito como (LATC&0b11) == 0b01
            cont++;
            if(cont > 99){ //Reinicio del contador
            cont = 99;
            }
            seleccion =0;
        }else if (resta ==1 & suma ==0){//// o puede ser escrito como (LATC&0b11) == 0b10
            cont--;
            if(cont < 0){ //Reinicio del contador
            cont = 0;
            }
            seleccion =0;
        }else if (suma==1 & resta==1){
            seleccion =1;
        }
        dec= cont/10; //Decenas (19/10 = 1)
        uni = cont%10; //Unidades (19%10 = 9)

        if (seleccion){         //muestra error
            for(int i=0;i< max;i++){
                LATD = num[10]; //Manda valor n del vector
                d1 = 1; //Enciendo display de unidades (Env�o un bit)
                delay_ms(50);
                d1 = 0; //Apago display de unidades

                LATD = num[10]; //Manda valor n del vector
                d2 = 1;//Enciendo display de decenas (Env�o un bit)
                delay_ms(50);
                d2 = 0;//Apago display de decenas
            }
            
        }else{
            for(int i=0;i< max;i++){
                LATD = num[uni]; //Manda valor n del vector
                d1 = 1; //Enciendo display de unidades (Env�o un bit)
                delay_ms(50);
                d1 = 0; //Apago display de unidades

                LATD = num[dec]; //Manda valor n del vector
                d2 = 1;//Enciendo display de decenas (Env�o un bit)
                delay_ms(50);
                d2 = 0;//Apago display de decenas
            }
        }

        /*if(cont > 99){ //Reinicio del contador
            cont = 0;
        }*/
    }
    return;
}
