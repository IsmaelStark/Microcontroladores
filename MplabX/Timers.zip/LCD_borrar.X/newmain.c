/*
 * File:   newmain.c
 * Author: PicTrance
 *
 * Created on 2 de julio de 2020, 12:17 PM
 */



#include <xc.h>
#include <stdio.h>
#include "..\1_libetriasYO\config.h"
#include "..\1_libetriasYO\lcd_yo.h"
#include "..\1_libetriasYO\Timer0.h"
//#include "..\1_libetriasYO\serial.h"
#include "..\1_libetriasYO\Timer1.h"

//hoy cabamos de ver tmr0 y veremos tmr1/3
//jueves tmr1, trm2
//martes pwm

void init(void){
    CMCON = 0X07;           //desactivo comparadores
    ADCON1bits.PCFG = 0x0F;    // 0x0F Todos los puertos  todo digital
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 0b00011111;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
    
    PORTE = 0X00;
    LATE = 0X00;
    TRISE = 0X00;
    //LATEbits.LATE0 =0;
    lcd_init();               //se inicializa la pantalla LCD.
}

void main(void) {
    //float cm;
    //char datos[20];
    init();
    timer0_config(T0_16_BIT, T0_INTERNAL, T0_DIV_128);
    timer1_config(T1_INTERNAL,T1_DIV_BY_8);
    
    lcd_clear();          //Limpiar pantalla LCD
    lcd_putc("**IDE MPLAB X**");  //se muestra una cadena de caracteres en la pantalla LCD
    lcd_putc("\n******XC8****LCD4x20");  
    lcd_putc("\nuControladores"); 
    lcd_putc("\nTimers en PIC18F4550");
    //lcd_cursor_on(1);
    //lcd_clear();
    delay_ms(500);    
    
    globalinterrupts = 1;
    peripheralInterrupt = 1;
    TMR1Interrupt = 1;
    
    TMR0 = 18660;
    TMR1 = 3035;
    
    while(1){
        led1 = !led1;
        delay_ms(100);
        
        Tarea!!!!!
        //while parpadea cada 100ms
        //tmr0 frec 10Hz
        //tmr1 frec 5Hz
        punto extra si hacen funcionar timer3 en modo interrupcion a frecuencia de 3Hz
    }
    return;
}

//void interrupt ISR_TIMER_0(void){
void __interrupt() ISR_TIMER(void){
    if (TMR0IF == 1){
    //if(INTCONbits.TMR0IF == 1){         //interrupcion timer0 Flag
        set_T0(18660);
        led5 = !led5;
        
        INTCONbits.TMR0IF = 0;
    }else
    
    if(PIR1bits.TMR1IF == 1){       //interrupcion timer1 Flag
    //if (TMR1IF == 1){
        TMR1 = 3035;
        led3 = !led3;
        //TMR1IF = 0;
        PIR1bits.TMR1IF = 0;
    }
    
}