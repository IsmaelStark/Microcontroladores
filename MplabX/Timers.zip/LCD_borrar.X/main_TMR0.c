/*
 * File:   newmain.c
 * Author: PicTrance
 *
 * Created on 2 de julio de 2020, 12:17 PM
 */


//#include <pic18f4550.h>
#include <xc.h>
#include "..\1_libetriasYO\config.h"
//#include "..\1_libetriasYO\lcd1.h"
#include <stdio.h>
#include <pic18f4550.h>
#include "..\1_libetriasYO\ADClib.h"

//#include "..\1_libetriasYO\SerialClase.h"

//#define led5 LATBbits.LB0

void init_timer0(){
    T0CONbits.T08BIT = 0;   // 1 = timer configurado a 8bits
    T0CONbits.T0CS = 0;     // 0 = selecciona reloj interno
    T0CONbits.PSA = 0;      //0= clk viene de preescaler, 1 = clk viene directo de Fosc/4
    T0CONbits.T0PS = 6;     //preescaler timer0, solo sirve si T0CONbits.PSA = 0;
    
    
    INTCONbits.TMR0IE = 1; // Permitir el desbordamiento del Timer0 para interrupcion
    T0CONbits.TMR0ON = 1;   //1 = habilito timer 0
}

void main(void) {
    //Definir puertos
    adc_config(NO_ANALOGS,VSS_VDD);
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 0X00;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0X00;
    
    led5=0;
    delay_ms(100);
    
    init_timer0();
    //TMR0L = 0;
    TMR0 = 18660;
    while(true){
        //if (INTCONbits.T0IF){
        //if (INTCONbits.TMR0IF){
        if (TMR0IF){
            TMR0 = 18660;
            led5 = !led5;
            TMR0IF=0;  
        }
        
        /*if (TMR0L==255){
            TMR0L = 20;
            led5 = !led5;
            //TMR0IF=0;
        }*/
    }
    return;
    
    
}
