#include <xc.h> 
#include "..\1_libetriasYO\config.h"
#include <stdint.h>

