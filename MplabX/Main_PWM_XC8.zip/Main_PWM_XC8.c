/*
 * File:   Main_PWM_XC8.c
 * Author: el_pa
 *
 * Created on 4 de agosto de 2020, 11:00 PM
 */

#include <xc.h>
#include <stdio.h>
#include "..\1_libetriasYO\config.h"
#include "..\1_libetriasYO\lcd_yo.h"
#include "..\1_libetriasYO\ADC.h"
//#include "..\1_libetriasYO\Timer0.h"
//#include "..\1_libetriasYO\serial.h"
//#include "..\1_libetriasYO\Timer1.h"
#include "..\1_libetriasYO\Timer2.h"

#define pwm     119
#define pwm_max 480
#define pwm_min 0

float map(float x, float in_min, float in_max, float out_min, float out_max){
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void init(void){
    CMCON = 0X07;           //desactivo comparadores
    ADCON1bits.PCFG = 0x0F;    // 0x0F Todos los puertos  todo digital
    PORTA = 0X00;
    LATA = 0X00;
    TRISA = 0b00011111;
    
    PORTB = 0X00;
    LATB = 0X00;
    TRISB = 0Xff;
    
    PORTE = 0X00;
    LATE = 0X00;
    TRISE = 0X00;
    //LATEbits.LATE0 =0;
    lcd_init();               //se inicializa la pantalla LCD.
}

void main(void) {
    unsigned short valoradc;
    short duty_cicle = 1;
    char datos[20];
    init();
    adc_config(AN0_TO_AN2,VSS_VDD);
    //timer0_config(T0_16_BIT, T0_INTERNAL, T0_DIV_128);
    //pwm_config(249,0);
    
    timer2_config(T2_DIV_BY_1,pwm,1);
    
    set_ccp1();
    //set_ccp2();
    
    //CCPR1L =245;
    set_pwm1_duty(4);
    //set_pwm2_duty(75);
    //CCPR2L =1;
    
    lcd_clear();          //Limpiar pantalla LCD
    lcd_putc("**IDE MPLAB X**");  //se muestra una cadena de caracteres en la pantalla LCD
    lcd_putc("\n******XC8****LCD4x20");  
    lcd_putc("\nuControladores"); 
    lcd_putc("\nPWM: PIC18F4550");
    //lcd_cursor_on(1);
    //lcd_clear();
    delay_ms(100);    
    lcd_clear();
    while(1){
        //led1 = !led1;
        //delay_ms(100);
        
        /*for(int i =0 ;i<=pwm_max;i++){
            //led1 = !led1;
            set_pwm1_duty(i);
            delay_ms(1);
        }
        
        for(int i =pwm_max ;i>=0;i--){
            //led1 = !led1;
            set_pwm1_duty(i);
            delay_ms(1);
        }*/
        
        /*if(btn1 == 0){
            duty_cicle += 1;
            if (duty_cicle > PR2){
                duty_cicle = PR2;
            }
            CCPR1L = duty_cicle;
        }
        if(btn0 == 0){
            duty_cicle = duty_cicle - 1;
            if (duty_cicle < 1){
                duty_cicle = 1;
            }
            CCPR1L = duty_cicle;
        } */
        lcd_clear();
        valoradc = adc_read(pot1);
        
        duty_cicle = map(valoradc, 0, 1023, 0, pwm_max);
        set_pwm1_duty(duty_cicle);
        lcd_gotoxy(1,1);
        sprintf(datos,"ADC: %d\n",valoradc);
        lcd_putc(datos);
        lcd_gotoxy(1,2);
        sprintf(datos,"Duty: %d",duty_cicle);
        lcd_putc(datos);
        delay_ms(100);
    }
    return;
}